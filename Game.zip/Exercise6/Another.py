print("Another")
print("Changes in another")
print("World")
print("More changes")

